<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/../includes/core/config.php';
require_once __DIR__ . '/../includes/core/api-client.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$token = $_GET['token'] ?? '';

if (empty($token)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Missing token. Usage: refresh.php?token={accessToken}',
    ]);
    exit;
}

$url = 'https://tm.tapi.videoready.tv/rest-api/v3/regenerateToken';
$res = ApiClient::androidRequest($url, $token, []);

http_response_code($res['code'] ?: 502);

if (is_array($res['data'])) {
    $res['data']['timestamp'] = date('Y-m-d H:i:s');
    echo json_encode($res['data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid response from API',
        'raw' => $res['raw'],
    ], JSON_PRETTY_PRINT);
}