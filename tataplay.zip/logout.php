<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/includes/core/functions.php';

// Verify CSRF token
$token = $_GET['token'] ?? '';
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    header('Content-Type: text/plain; charset=utf-8');
    die('Unauthorized logout attempt: Invalid or missing CSRF token.');
}

// Delete account file (unless admin_only mode)
if (!isset($_GET['admin_only']) && is_logged_in()) {
    if (defined('ACCOUNT_FILE') && file_exists(ACCOUNT_FILE)) {
        @unlink(ACCOUNT_FILE);
    }
    if (defined('STREAM_CACHE_FILE') && file_exists(STREAM_CACHE_FILE)) {
        @unlink(STREAM_CACHE_FILE);
    }
}

session_unset();
session_destroy();

header("Location: login");
exit;