<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/includes/core/functions.php';

$channelsFile = CHANNELS_FILE;
if (!file_exists($channelsFile)) {
    header("HTTP/1.1 404 Not Found");
    die("Channels data not found. Please login first to generate channels.json.");
}

$channels = json_decode(file_get_contents($channelsFile), true);
if (!$channels) {
    header("HTTP/1.1 500 Internal Server Error");
    die("Invalid channels data format.");
}

$epgUrl = "https://tsepg.cf/epg.xml.gz";

// Calculate base URL robustly using helper
$baseUrl = getBaseUrl();

// Build M3U header
$output = "#EXTM3U url-tvg=\"$epgUrl\"\n";
$output .= "# Crafted with ❤️ by LazyyXD\n\n";

// Intro channel
$introImg = "https://res.cloudinary.com/dlzxf85nw/image/upload/q_auto/f_auto/v1781383535/lazyyxd_q3xbb3.png";
$introVid = "https://embed-cloudfront.wistia.com/deliveries/76460d52df33cb0da623bad0f7c841813eb4663b.m3u8";
$output .= "#EXTINF:-1 tvg-id=\"lazyyxd\" tvg-type=\"live\" tvg-logo=\"$introImg\" group-logo=\"$introImg\" group-title=\"About\",LazyyXD\n";
$output .= "#KODIPROP:inputstream.adaptive.manifest_type=hls\n";
$output .= "$introVid\n\n";

foreach ($channels as $ch) {
    $id = $ch['tvg_id'] ?? '';
    $name = $ch['tvg_name'] ?? 'TATA PLAY';
    $logo = $ch['tvg_logo'] ?? '';
    $group = $ch['group_title'] ?? '';
    $groupLogo = $ch['group_logo'] ?? 'https://pub-d9e70e5abf3a43bcadb504fbe8d10dfa.r2.dev/tp.png';

    $manifestType = strtolower($ch['manifest_type'] ?? 'dash');
    if ($manifestType === 'dash') {
        $manifestType = 'mpd';
    }

    $ua = $ch['user_agent'] ?? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36';
    $referer = $ch['referer'] ?? 'https://watch.tataplay.com/';

    $output .= "#EXTINF:-1 tvg-id=\"$id\" catchup-type=\"append\" catchup-days=\"7\" catchup-source=\"&begin={utc}&end={utcend}\" tvg-type=\"live\" tvg-logo=\"$logo\" group-logo=\"$groupLogo\" group-title=\"$group\",$name\n";
    $output .= "#EXTVLCOPT:http-user-agent=$ua\n";
    $output .= "#EXTVLCOPT:http-referrer=$referer\n";
    $output .= "#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha\n";
    $output .= "#KODIPROP:inputstream.adaptive.license_key=$baseUrl/$id/license\n";
    $output .= "#KODIPROP:inputstream.adaptive.manifest_type=$manifestType\n";
    $output .= "$baseUrl/$id/stream/lazyyxd.$manifestType\n\n";
}

header("Content-Type: text/plain; charset=utf-8");
echo $output;