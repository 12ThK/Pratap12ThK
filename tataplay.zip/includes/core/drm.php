<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/api-client.php';
require_once __DIR__ . '/cache.php';
require_once __DIR__ . '/channel-utils.php';

/**
 * Widevine DRM, JWT, HMAC, and PSSH extraction
 */
class DrmHandler
{
    private const AES_KEY = 'aesEncryptionKey';

    /**
     * Decrypt AES-128-ECB encoded URL/token
     */
    public static function decryptAes(string $encrypted): string
    {
        $decrypted = @openssl_decrypt(
            base64_decode(explode('#', $encrypted)[0]),
            'AES-128-ECB',
            self::AES_KEY,
            OPENSSL_RAW_DATA
        );
        return $decrypted ?: $encrypted;
    }

    /**
     * Generate JWT token for streaming/license
     */
    public static function generateJwt(string $channelId): ?string
    {
        $epids = ChannelUtils::getEntitlements($channelId);
        $creds = Auth::getAccount();
        if (!$creds)
            return null;

        $url = 'https://tm.tapi.videoready.tv/auth-service/v3/sampling/token-service/token';
        $payload = [
            'action' => 'stream',
            'epids' => $epids,
            'samplingExpiry' => 'ucPtCl63EsD1qBrlIhY9nw==#v2',
        ];

        $headers = [
            'content-type: application/json',
            'locale: ENG',
            'x-device-platform: PC',
            'x-device-type: WEB',
            'x-subscriber-id: ' . $creds['sid'],
            'x-subscriber-name: ' . $creds['sname'],
            'User-Agent: ' . 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
        ];

        $res = ApiClient::webAuthenticatedRequest($url, $creds, $payload, $headers);

        if (isset($res['data']['code']) && $res['data']['code'] === 0 && isset($res['data']['data']['token'])) {
            return $res['data']['data']['token'];
        }

        return $creds['accessToken']; // Fallback to access token
    }

    /**
     * Decode JWT payload
     */
    public static function decodeJwt(string $jwt): ?array
    {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3)
            return null;
        $payload = base64_decode(strtr($parts[1], '-_', '+/'));
        return json_decode($payload, true);
    }

    /**
     * Get HMAC token for a channel stream
     */
    public static function getHmac(string $channelId): ?string
    {
        // Try cache first
        if ($cached = StreamCache::getHmac($channelId)) {
            return $cached;
        }

        $creds = Auth::getAccount();
        if (!$creds)
            return null;

        $url = "https://tm.tapi.videoready.tv/digital-feed-services/api/partner/cdn/player/details/LIVE/{$channelId}";

        $headers = [
            'accept: */*',
            'authorization: ' . $creds['accessToken'],
            'content-type: application/json',
            'device_details: {"pl":"web","os":"WINDOWS","lo":"en-us","app":"1.44.7","dn":"PC","bv":129,"bn":"CHROME","device_id":"7683d93848b0f472c508e38b1827038a","device_type":"WEB","device_platform":"PC","device_category":"open","manufacturer":"WINDOWS_CHROME_129","model":"PC","sname":"' . ($creds['sname'] ?? '') . '"}',
            'locale: ENG',
            'origin: https://watch.tataplay.com',
            'platform: web',
            'profileid: ' . ($creds['profileId'] ?? ''),
            'referer: https://watch.tataplay.com/'
        ];

        $res = ApiClient::execute($url, null, $headers);

        if ($res['code'] === 403) {
            return 'GEO_BLOCKED';
        }

        if ($res['code'] === 200 && isset($res['data']['data'])) {
            return self::extractHmacFromResponse($res['data']['data'], $channelId);
        }

        return null;
    }

    /**
     * Extract HMAC from CDN player details response
     */
    private static function extractHmacFromResponse(array $data, string $channelId): ?string
    {
        $encryptedToken = $data['dashWidewinePlayUrl'] ?? $data['playUrl'] ?? '';
        if (empty($encryptedToken))
            return null;

        $decrypted = self::decryptAes($encryptedToken);
        $hdntl = null;

        // 1. Check if token is already in the URL
        if (strpos($decrypted, 'hdnea=') !== false || strpos($decrypted, 'hdntl=') !== false) {
            $parts = explode('?', $decrypted);
            if (isset($parts[1])) {
                $hdntl = $parts[1];
            }
        }

        // 2. If not in URL, try fetching cookies via HEAD request
        if (!$hdntl) {
            $headerResponse = ApiClient::fetchContent($decrypted, true);
            if ($headerResponse && $headerResponse !== 'GEO_BLOCKED') {
                if (preg_match('/hdntl=(.*?)(;|$)/', $headerResponse, $matches)) {
                    $hdntl = 'hdntl=' . $matches[1];
                } elseif (preg_match('/hdnea=(.*?)(;|$)/', $headerResponse, $matches)) {
                    $hdntl = 'hdnea=' . $matches[1];
                }
            }
        }

        if (!$hdntl)
            return null;

        // Extract expiry time
        preg_match('/exp=(\d+)/', (string) $hdntl, $expMatches);
        $expTime = isset($expMatches[1]) ? (int) $expMatches[1] : time() + 600;

        // Extract license URL
        $licUrl = $data['dashWidewineLicenseUrl'] ?? $data['dashWidevineLicenseUrl']
            ?? "https://tataplay.live.ott.irdeto.com/Widevine/getlicense?CrmId=tatasky&AccountId=tatasky&ContentId=4000000$channelId";
        $licUrl = self::decryptAes($licUrl);

        // Get channel name for cache
        $channelName = ChannelUtils::getChannelName($channelId);

        // Cache the full details
        $details = [
            'channel_name' => $channelName,
            'manifest_url' => explode('?', $decrypted)[0],
            'license_url' => $licUrl,
            'hmac' => $hdntl,
        ];
        StreamCache::setChannel($channelId, $details, $expTime);

        return $hdntl;
    }

    /**
     * Extract Widevine PSSH from MPD content
     */
    public static function extractPssh(string $mpdContent, string $baseUrl, ?int $catchupRequest = null): ?array
    {
        $xml = @simplexml_load_string($mpdContent);
        if ($xml === false)
            return null;

        foreach ($xml->Period->AdaptationSet as $set) {
            if ((string) $set['contentType'] === 'audio') {
                foreach ($set->Representation as $rep) {
                    $template = $rep->SegmentTemplate ?? null;
                    if (!$template)
                        continue;

                    $startNumber = $catchupRequest
                        ? (int) ($template['startNumber'] ?? 0)
                        : (int) ($template['startNumber'] ?? 0) + (int) ($template->SegmentTimeline->S['r'] ?? 0);

                    $media = str_replace(
                        ['$RepresentationID$', '$Number$'],
                        [(string) $rep['id'], $startNumber],
                        $template['media']
                    );
                    $url = "$baseUrl/dash/$media";

                    $content = ApiClient::fetchContent($url);
                    if ($content && $content !== 'GEO_BLOCKED') {
                        return self::extractKidFromHex(bin2hex($content));
                    }
                }
            }
        }
        return null;
    }

    /**
     * Extract KID from hex content and build PSSH
     */
    private static function extractKidFromHex(string $hexContent): ?array
    {
        $psshMarker = '70737368';
        $psshOffset = strpos($hexContent, $psshMarker);

        if ($psshOffset === false)
            return null;

        $headerSizeHex = substr($hexContent, $psshOffset - 8, 8);
        $headerSize = hexdec($headerSizeHex);
        $psshHex = substr($hexContent, $psshOffset - 8, $headerSize * 2);
        $kidHex = substr($psshHex, 68, 32);

        $newPsshHex = '000000327073736800000000edef8ba979d64acea3c827dcd51d21ed000000121210' . $kidHex;
        $pssh = base64_encode(hex2bin($newPsshHex));
        $kid = substr($kidHex, 0, 8) . '-' . substr($kidHex, 8, 4) . '-' . substr($kidHex, 12, 4) . '-' . substr($kidHex, 16, 4) . '-' . substr($kidHex, 20);

        return ['pssh' => $pssh, 'kid' => $kid];
    }
}