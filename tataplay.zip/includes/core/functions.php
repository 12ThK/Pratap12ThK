<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/drm.php';
require_once __DIR__ . '/cache.php';
require_once __DIR__ . '/channel-utils.php';

// ─── BACKWARD COMPATIBILITY WRAPPERS ────────────────────────
// These keep the old function names working for files not yet updated

function is_logged_in(): bool
{
    return Auth::isLoggedIn();
}

function get_creds(): ?array
{
    return Auth::getAccount();
}

function rate_limit_check(string $action, int $max = 5, int $period = 300): bool
{
    return Auth::checkRateLimit($action, $max, $period);
}

function request_otp(string $input): array
{
    return Auth::generateOtp($input);
}

function verify_otp(string $sid, string $rmn, string $otp): array
{
    return Auth::verifyOtp($sid, $rmn, $otp);
}

function save_raw_account(array $data): bool
{
    return Auth::saveAccount($data);
}

function refresh_tplay_token(): array
{
    $creds = Auth::getAccount();
    if (!$creds) {
        return ['status' => 'error', 'message' => 'Account file not found. Please login first.'];
    }
    return Auth::refreshToken($creds['accessToken']);
}

function check_and_download_channels(): bool
{
    return ChannelUtils::downloadIfMissing();
}

// ─── UTILITIES ──────────────────────────────────────────────
// Robustly calculate base URL handling proxies and script depth
function getBaseUrl(): string
{
    $isSecure = false;
    if (isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) === 'on') {
        $isSecure = true;
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        $isSecure = true;
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on') {
        $isSecure = true;
    }

    $protocol = $isSecure ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    // Calculate the directory path relative to the document root
    $docRoot = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $rootDir = str_replace('\\', '/', ROOT_DIR);

    // If project is inside a subfolder, extract that path
    $dir = str_replace($docRoot, '', $rootDir);
    $dir = rtrim($dir, '/');

    return $protocol . $host . $dir;
}

function getHmac(string $id): ?string
{
    return DrmHandler::getHmac($id);
}

function generateJWT(string $channelId): ?string
{
    return DrmHandler::generateJwt($channelId);
}

function fetchContent(string $url, bool $wantHeaders = false): ?string
{
    return ApiClient::fetchContent($url, $wantHeaders);
}

function get_client_ip(): string
{
    return Auth::getClientIp();
}

// Stream cache wrappers
function cache_updater(string $utility, array $content, string $id, int $exp): void
{
    if ($utility !== 'channel')
        return;
    StreamCache::setChannel($id, $content, $exp);
}

function cache_retrive(string $utility, string $id)
{
    if ($utility === 'hmac')
        return StreamCache::getHmac($id);
    if ($utility === 'channel')
        return StreamCache::getChannel($id);
    return false;
}

function extractWidevinePssh(string $content, string $baseUrl, ?int $catchupRequest): ?array
{
    return DrmHandler::extractPssh($content, $baseUrl, $catchupRequest);
}

function decodeJWT(string $jwt): ?array
{
    return DrmHandler::decodeJwt($jwt);
}