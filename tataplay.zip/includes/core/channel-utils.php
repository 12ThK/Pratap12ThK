<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/api-client.php';

/**
 * Channel & EPG utility functions
 */
class ChannelUtils
{
    /**
     * Download channels.json if missing
     */
    public static function downloadIfMissing(): bool
    {
        if (!defined('CHANNELS_FILE') || !defined('CHANNELS_SOURCE_URL')) {
            return false;
        }

        if (file_exists(CHANNELS_FILE)) {
            return true;
        }

        $content = ApiClient::fetchContent(CHANNELS_SOURCE_URL);
        if ($content && $content !== 'GEO_BLOCKED' && !empty($content)) {
            $dir = dirname(CHANNELS_FILE);
            if (!file_exists($dir)) {
                @mkdir($dir, 0755, true);
            }
            return @file_put_contents(CHANNELS_FILE, $content) !== false;
        }

        return false;
    }

    /**
     * Load all channels from JSON
     */
    public static function loadAll(): array
    {
        $file = defined('CHANNELS_FILE') ? CHANNELS_FILE : DATA_DIR . '/channels.json';
        if (!file_exists($file)) {
            self::downloadIfMissing();
        }
        if (file_exists($file)) {
            return json_decode(file_get_contents($file), true) ?? [];
        }
        return [];
    }

    /**
     * Get channel name by ID
     */
    public static function getChannelName(string $channelId): string
    {
        $channels = self::loadAll();
        foreach ($channels as $ch) {
            if (isset($ch['tvg_id']) && $ch['tvg_id'] === "ts$channelId") {
                return $ch['tvg_name'] ?? "Channel $channelId";
            }
        }
        return "Channel $channelId";
    }

    /**
     * Get channel entitlements for JWT generation
     */
    public static function getEntitlements(string $channelId): array
    {
        $creds = Auth::getAccount();
        if (!$creds)
            return [];

        $url = 'https://tm.tapi.videoready.tv/content-detail/pub/api/v6/channels/' . $channelId . '?platform=WEB';
        $res = ApiClient::webAuthenticatedRequest($url, $creds);

        if ($res['code'] !== 200 || !isset($res['data']['data']['detail']['entitlements'])) {
            return [['epid' => 'Subscription', 'bid' => '1000000190']];
        }

        $entitlements = $res['data']['data']['detail']['entitlements'];
        $specialId = '1000001274';

        if (in_array($specialId, $entitlements)) {
            return [['epid' => 'Subscription', 'bid' => $specialId]];
        } elseif (!empty($entitlements)) {
            return [['epid' => 'Subscription', 'bid' => $entitlements[0]]];
        }

        return [['epid' => 'Subscription', 'bid' => '1000000190']];
    }

    /**
     * Fetch EPG schedule for a channel
     */
    public static function fetchEpg(string $channelId): array
    {
        $url = TP_EPG_API . '/content-detail/pub/api/v5/channels/' . urlencode($channelId);
        $content = ApiClient::fetchContent($url);

        if ($content && $content !== 'GEO_BLOCKED') {
            $data = json_decode($content, true);
            return $data['data']['channelScheduleData'] ?? [];
        }

        return [];
    }
}