//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//               Version: 2.0 Refactored
//=============================================================================//

/**
 * Auth Bridge - Connects frontend UI to PHP auth backend
 */
const AuthBridge = {
    csrf: document.querySelector('meta[name="csrf-token"]').content,
    sidAtOtp: null,
    rmnAtOtp: null,

    init() {
        document.addEventListener('tata:generateOtp', (e) => this.handleGenerateOtp(e.detail.sid));
        document.addEventListener('tata:resendOtp', (e) => this.handleGenerateOtp(e.detail.sid, true));
        document.addEventListener('tata:verifyOtp', (e) => this.handleVerifyOtp(e.detail.sid, e.detail.otp));
    },

    async handleGenerateOtp(sid, isResend = false) {
        const formData = new FormData();
        formData.append('action', 'get_otp');
        formData.append('sid', sid);
        formData.append('csrf_token', this.csrf);

        try {
            const response = await fetch('api/auth.php', { method: 'POST', body: formData });
            const result = await response.json();

            if (result.status === 'success') {
                this.sidAtOtp = result.sid;
                this.rmnAtOtp = result.rmn;
                window.TataAuth.onOtpSent(result.message);
            } else {
                window.TataAuth.onOtpSentError(result.message);
            }
        } catch (err) {
            window.TataAuth.onOtpSentError('Network connectivity issue. Please try again.');
        }
    },

    async handleVerifyOtp(sid, otp) {
        const formData = new FormData();
        formData.append('action', 'verify_otp');
        formData.append('sid', this.sidAtOtp || sid);
        formData.append('rmn', this.rmnAtOtp || '');
        formData.append('otp', otp);
        formData.append('csrf_token', this.csrf);

        try {
            const response = await fetch('api/auth.php', { method: 'POST', body: formData });
            const result = await response.json();

            if (result.status === 'success') {
                window.TataAuth.onLoginSuccess('home');
            } else {
                window.TataAuth.onLoginError(result.message);
            }
        } catch (err) {
            window.TataAuth.onLoginError('Verification failed due to a network error.');
        }
    },
};

document.addEventListener('DOMContentLoaded', () => AuthBridge.init());