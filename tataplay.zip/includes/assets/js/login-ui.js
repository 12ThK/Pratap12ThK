//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//               Version: 2.0 Refactored
//=============================================================================//

(function () {
    'use strict';

    /* ── GSAP ENTRANCE ── */
    const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });
    tl.fromTo('#elBrand', { y: -14, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45 })
        .fromTo('#elCard', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5 }, '-=0.25')
        .fromTo('#elHead', { y: 8, opacity: 0 }, { y: 0, opacity: 1, duration: 0.35 }, '-=0.3')
        .fromTo('#elSteps', { y: 8, opacity: 0 }, { y: 0, opacity: 1, duration: 0.3 }, '-=0.2')
        .fromTo('#grpSid', { y: 8, opacity: 0 }, { y: 0, opacity: 1, duration: 0.3 }, '-=0.15')
        .fromTo('#btnGroup', { y: 6, opacity: 0 }, { y: 0, opacity: 1, duration: 0.3 }, '-=0.1')
        .fromTo('#elFooter', { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: 0.4 }, '-=0.1');

    /* ── DOM ELEMENTS ── */
    const form = document.getElementById('authForm');
    const elAlert = document.getElementById('elAlert');
    const alertIcon = document.getElementById('alertIcon');
    const alertText = document.getElementById('alertText');
    const authValue = document.getElementById('authValue');
    const authBtn = document.getElementById('authBtn');
    const btnLabel = document.getElementById('btnLabel');
    const btnIcon = document.getElementById('btnIcon');
    const btnSpinner = document.getElementById('btnSpinner');
    const grpSid = document.getElementById('grpSid');
    const grpOtp = document.getElementById('grpOtp');
    const otpBoxes = document.querySelectorAll('.otp-box');
    const sidCounter = document.getElementById('sidCounter');
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const s1num = document.getElementById('s1num');
    const resendBtn = document.getElementById('resendBtn');
    const timerText = document.getElementById('timerText');
    const timerVal = document.getElementById('timerVal');
    const headTitle = document.getElementById('headTitle');
    const headSub = document.getElementById('headSub');

    let step = 'sid', busy = false, resendTimer = null;

    /* ── SID COUNTER ── */
    authValue.addEventListener('input', () => {
        authValue.value = authValue.value.replace(/\D/g, '');
        const n = authValue.value.length;
        sidCounter.textContent = `${n} / 10`;
        sidCounter.className = 'counter' + (n === 10 ? ' full' : n >= 7 ? ' warm' : '');
    });

    /* ── OTP NAVIGATION ── */
    otpBoxes.forEach((box, i) => {
        box.addEventListener('input', e => {
            box.value = e.target.value.replace(/\D/g, '').slice(-1);
            if (box.value && i < 5) otpBoxes[i + 1].focus();
            authBtn.disabled = busy || getOTP().length < 4;
        });
        box.addEventListener('keydown', e => {
            if (e.key === 'Backspace' && !box.value && i > 0) {
                otpBoxes[i - 1].value = '';
                otpBoxes[i - 1].focus();
            }
            if (e.key === 'ArrowLeft' && i > 0) otpBoxes[i - 1].focus();
            if (e.key === 'ArrowRight' && i < 5) otpBoxes[i + 1].focus();
        });
        box.addEventListener('paste', e => {
            e.preventDefault();
            const p = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
            p.split('').slice(0, 6).forEach((ch, idx) => { if (otpBoxes[idx]) otpBoxes[idx].value = ch; });
            otpBoxes[Math.min(p.length - 1, 5)].focus();
            authBtn.disabled = busy || getOTP().length < 4;
        });
    });

    function getOTP() { return [...otpBoxes].map(b => b.value).join(''); }

    /* ── ALERT SYSTEM ── */
    const ICONS = {
        error: '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>',
        success: '<polyline points="20 6 9 17 4 12"/>',
        info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
        warn: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    };
    let alertTimeout = null;

    function showAlert(type, msg) {
        clearTimeout(alertTimeout);
        elAlert.className = `alert alert-${type} show`;
        alertIcon.innerHTML = ICONS[type] || ICONS.info;
        alertText.textContent = msg;
        gsap.fromTo(elAlert, { y: -6, opacity: 0 }, { y: 0, opacity: 1, duration: 0.28, ease: 'power2.out' });
        alertTimeout = setTimeout(() => {
            gsap.to(elAlert, {
                opacity: 0, y: -5, duration: 0.4, onComplete: () => {
                    elAlert.className = 'alert';
                    gsap.set(elAlert, { opacity: 1, y: 0 });
                }
            });
        }, 3000);
    }

    function hideAlert() { clearTimeout(alertTimeout); elAlert.className = 'alert'; }

    /* ── LOADING STATE ── */
    function setLoading(on) {
        busy = on;
        authBtn.disabled = on;
        btnSpinner.style.display = on ? 'block' : 'none';
        btnIcon.style.display = on ? 'none' : 'block';
    }

    /* ── TRANSITION TO OTP STEP ── */
    function goOTP() {
        step = 'otp';
        step1.classList.remove('active'); step1.classList.add('done');
        s1num.innerHTML = '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>';
        step2.classList.add('active');
        headTitle.textContent = 'Verify your identity';
        headSub.textContent = 'Enter the 6-digit OTP sent to your registered mobile';
        btnLabel.textContent = 'Verify & Sign In';
        btnIcon.innerHTML = '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>';
        authBtn.disabled = true;
        gsap.to(grpSid, {
            opacity: 0, y: -8, duration: 0.22, onComplete: () => {
                grpSid.style.display = 'none';
                grpOtp.style.display = 'block';
                gsap.fromTo(grpOtp, { opacity: 0, y: 8 }, {
                    opacity: 1, y: 0, duration: 0.28, ease: 'power2.out',
                    onComplete: () => otpBoxes[0].focus()
                });
            }
        });
        startTimer();
    }

    /* ── RESEND TIMER ── */
    function startTimer(sec = 30) {
        let t = sec;
        timerText.style.display = '';
        resendBtn.disabled = true;
        resendBtn.classList.remove('ready');
        clearInterval(resendTimer);
        timerVal.textContent = `${t}s`;
        resendTimer = setInterval(() => {
            t--;
            timerVal.textContent = `${t}s`;
            if (t <= 0) {
                clearInterval(resendTimer);
                timerText.style.display = 'none';
                resendBtn.disabled = false;
                resendBtn.classList.add('ready');
            }
        }, 1000);
    }

    resendBtn.addEventListener('click', () => {
        if (busy) return;
        hideAlert();
        resendBtn.disabled = true;
        resendBtn.classList.remove('ready');
        document.dispatchEvent(new CustomEvent('tata:resendOtp', { detail: { sid: authValue.value } }));
        showAlert('info', 'A new OTP has been sent to your registered mobile number.');
        startTimer(30);
    });

    /* ── FORM SUBMIT ── */
    form.addEventListener('submit', e => {
        e.preventDefault();
        if (busy) return;
        hideAlert();

        if (step === 'sid') {
            const sid = authValue.value.trim();
            if (!/^\d{10}$/.test(sid)) {
                showAlert('error', 'Please enter a valid 10-digit ID or Mobile Number.');
                gsap.fromTo(authValue, { x: -5 }, { x: 0, duration: 0.45, ease: 'elastic.out(1,0.4)' });
                return;
            }
            setLoading(true);
            document.dispatchEvent(new CustomEvent('tata:generateOtp', { detail: { sid } }));
        } else {
            const otp = getOTP();
            if (otp.length < 4) {
                showAlert('error', 'Please enter at least 4 digits of your OTP.');
                return;
            }
            setLoading(true);
            document.dispatchEvent(new CustomEvent('tata:verifyOtp', { detail: { sid: authValue.value, otp } }));
        }
    });

    /* ── PUBLIC API FOR AUTH-BRIDGE ── */
    window.TataAuth = {
        onOtpSent(msg) {
            setLoading(false);
            showAlert('success', msg || 'OTP sent to your registered mobile number.');
            setTimeout(() => { hideAlert(); goOTP(); }, 800);
        },
        onOtpSentError(msg) {
            setLoading(false);
            showAlert('error', msg || 'Failed to send OTP. Please try again.');
            gsap.fromTo('#elCard', { x: -5 }, { x: 0, duration: 0.5, ease: 'elastic.out(1,0.4)' });
        },
        onLoginSuccess(url) {
            setLoading(false);
            clearInterval(resendTimer);
            showAlert('success', 'Authenticated. Redirecting you now…');
            gsap.to('#elCard', {
                opacity: 0, y: -10, scale: 0.98, duration: 0.4, delay: 0.9,
                onComplete: () => { window.location.href = url || 'home'; }
            });
        },
        onLoginError(msg) {
            setLoading(false);
            showAlert('error', msg || 'Incorrect OTP. Please try again.');
            otpBoxes.forEach(b => {
                gsap.fromTo(b, { x: -5 }, { x: 0, duration: 0.4, ease: 'elastic.out(1,0.4)' });
            });
            authBtn.disabled = true;
            otpBoxes[0].focus();
        },
        showInfo(msg) { showAlert('info', msg); },
    };
}());