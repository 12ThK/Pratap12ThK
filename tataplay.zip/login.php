<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/includes/core/functions.php';

if (is_logged_in()) {
    header("Location: home");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Tata Play DTH — Sign In</title>
    <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; ?>">
    <link rel="shortcut icon" href="includes/assets/images/favicon.ico" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
        rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <link href="includes/assets/css/styles.css" rel="stylesheet">
    <style>
        :root {
            --bg: #07070a;
            --surface: rgba(14, 14, 20, 0.75);
            --surface-2: #15151f;
            --surface-3: #1c1c2b;
            --border: rgba(255, 255, 255, 0.06);
            --border-hover: rgba(57, 255, 20, 0.3);
            --text: #f0f0f5;
            --text-2: #a0a0b8;
            --text-3: #606078;
            --font: 'Space Grotesk', sans-serif;
            --mono: 'JetBrains Mono', monospace;
            --green: #39ff14;
            --green-soft: rgba(57, 255, 20, 0.15);
            --green-glow: rgba(57, 255, 20, 0.25);
            --red: #ff4d4d;
            --blue: #39ff14;
            --blue-light: #4fff3f;
            --blue-soft: rgba(57, 255, 20, 0.15);
            --blue-glow: rgba(57, 255, 20, 0.25);
        }

        * {
            scrollbar-width: thin;
            scrollbar-color: rgba(57, 255, 20, 0.2) var(--bg);
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(57, 255, 20, 0.15);
            border-radius: 3px;
            border: 1px solid rgba(57, 255, 20, 0.25);
            transition: all 0.3s;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--green);
            border-color: var(--green);
            box-shadow: 0 0 10px var(--green-glow);
        }

        body {
            background: var(--bg);
            color: var(--text);
            position: relative;
            align-items: center;
            justify-content: center;
            padding: 24px 16px 72px;
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image: radial-gradient(circle 600px at 50% 280px, rgba(16, 185, 129, 0.28), transparent 70%);
            background-size: unset;
            pointer-events: none;
            z-index: 0;
        }

        body::after {
            display: none !important;
            content: none;
        }

        .input-wrap:focus-within .input-icon {
            color: var(--green);
        }

        .card {
            background: rgba(14, 14, 20, 0.75);
            backdrop-filter: blur(32px) saturate(1.6);
            -webkit-backdrop-filter: blur(32px) saturate(1.6);
            border: 1px solid rgba(255, 255, 255, 0.06);
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.06);
        }

        .card::before {
            background: linear-gradient(90deg, transparent, var(--green), #4fff3f, var(--green), transparent);
        }

        .steps {
            background: rgba(255, 255, 255, 0.03);
            border-color: rgba(255, 255, 255, 0.06);
        }

        .step-pill.active {
            background: rgba(255, 255, 255, 0.06);
            color: var(--text);
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.05);
        }

        .step-pill.active .step-num {
            background: var(--green);
            border-color: var(--green);
            box-shadow: 0 0 10px var(--green-glow);
            color: #000;
            font-weight: 700;
        }

        input[type="tel"],
        input[type="text"],
        input[type="password"] {
            background: rgba(255, 255, 255, 0.03);
            border-color: rgba(255, 255, 255, 0.06);
            color: var(--text);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }

        input:focus {
            border-color: rgba(57, 255, 20, 0.5);
            box-shadow: 0 0 0 3px rgba(57, 255, 20, 0.1), 0 0 20px rgba(57, 255, 20, 0.1);
            background: rgba(255, 255, 255, 0.05);
        }

        .btn {
            background: linear-gradient(135deg, var(--green), #10b981);
            color: #000;
            box-shadow: 0 4px 16px rgba(57, 255, 20, 0.25);
            font-weight: 700;
        }

        .btn:hover:not(:disabled) {
            background: linear-gradient(135deg, #4fff3f, #10b981);
            box-shadow: 0 6px 24px rgba(57, 255, 20, 0.35);
            transform: translateY(-1px);
        }

        .alert {
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        .alert-error {
            background: rgba(255, 77, 77, 0.08);
            border-color: rgba(255, 77, 77, 0.2);
            color: var(--red);
            box-shadow: 0 0 15px rgba(255, 77, 77, 0.1), inset 0 1px 0 rgba(255, 77, 77, 0.1);
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.08);
            border-color: rgba(16, 185, 129, 0.2);
            color: var(--green);
            box-shadow: 0 0 15px rgba(16, 185, 129, 0.1), inset 0 1px 0 rgba(16, 185, 129, 0.1);
        }

        .site-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 100;
            background: rgba(7, 7, 10, 0.85) !important;
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-top: 1px solid rgba(255, 255, 255, 0.06) !important;
        }

        .footer-inner {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 40px;
            padding: 0 20px;
            padding-bottom: env(safe-area-inset-bottom, 0px);
            text-align: center;
            font-size: 12px;
            color: var(--text-3);
            font-weight: 500;
            line-height: 1;
        }

        .footer-inner a {
            color: var(--green);
            text-decoration: none;
            font-weight: 600;
            text-shadow: 0 0 8px var(--green-glow);
            transition: all 0.2s;
        }

        .footer-inner a:hover {
            color: #4fff3f;
        }

        .footer-heart {
            color: var(--red);
            text-shadow: 0 0 8px rgba(255, 77, 77, 0.3);
        }

        .brand-logo-wrap {
            border: 1px solid rgba(255, 255, 255, 0.06);
            background: rgba(255, 255, 255, 0.02);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);
        }

        .brand-logo-wrap img {
            filter: drop-shadow(0 0 8px var(--green-glow));
        }

        .brand-name span {
            color: var(--green);
        }

        .brand-tag {
            background: rgba(57, 255, 20, 0.1);
            color: var(--green);
            border: 1px solid rgba(57, 255, 20, 0.15);
            padding: 2px 6px;
            border-radius: 4px;
            font-family: var(--mono);
            font-size: 10px;
            text-transform: uppercase;
        }
    </style>
</head>

<body>
    <div class="page-content">
        <div class="brand" id="elBrand">
            <div class="brand-logo-wrap">
                <img src="includes/assets/images/logo.png" alt="Tata Play" onerror="this.style.display='none'">
            </div>
            <span class="brand-name">TATA <span>PLAY</span></span>
            <div class="brand-sep"></div>
            <span class="brand-tag">Login</span>
        </div>

        <div class="card" id="elCard">
            <div class="card-head" id="elHead">
                <h1 id="headTitle">Welcome back</h1>
                <p id="headSub">Sign in to your Tata Play DTH account</p>
            </div>

            <div class="steps" id="elSteps">
                <div class="step-pill active" id="step1">
                    <div class="step-num" id="s1num">1</div>
                    <span>Mobile Number</span>
                </div>
                <div class="step-pill" id="step2">
                    <div class="step-num">2</div>
                    <span>Verify OTP</span>
                </div>
            </div>

            <div class="alert" id="elAlert" role="alert">
                <svg id="alertIcon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    stroke-width="2.5" stroke-linecap="round"></svg>
                <span id="alertText"></span>
            </div>

            <form id="authForm" autocomplete="off" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group" id="grpSid">
                    <div class="form-label">
                        <label for="authValue">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2.5" stroke-linecap="round">
                                <circle cx="12" cy="8" r="4" />
                                <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
                            </svg>
                            Registered Mobile Number
                        </label>
                        <span class="counter" id="sidCounter">0 / 10</span>
                    </div>
                    <div class="input-wrap">
                        <svg class="input-icon" width="15" height="15" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round">
                            <rect x="5" y="2" width="14" height="20" rx="2" />
                            <line x1="12" y1="18" x2="12.01" y2="18" stroke-width="3" />
                        </svg>
                        <input type="tel" id="authValue" name="sid" placeholder="Enter 10-digit RMN" maxlength="10"
                            inputmode="numeric" pattern="[0-9]{10}" required autocomplete="off">
                    </div>
                </div>

                <div class="form-group" id="grpOtp" style="display:none;">
                    <div class="form-label">
                        <label>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2.5" stroke-linecap="round">
                                <rect x="3" y="11" width="18" height="11" rx="2" />
                                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                            </svg>
                            One-Time Password
                        </label>
                    </div>
                    <div class="otp-row" id="otpGrid">
                        <input type="tel" maxlength="1" inputmode="numeric" class="otp-box" placeholder="·"
                            autocomplete="one-time-code">
                        <input type="tel" maxlength="1" inputmode="numeric" class="otp-box" placeholder="·">
                        <input type="tel" maxlength="1" inputmode="numeric" class="otp-box" placeholder="·">
                        <input type="tel" maxlength="1" inputmode="numeric" class="otp-box" placeholder="·">
                        <input type="tel" maxlength="1" inputmode="numeric" class="otp-box" placeholder="·">
                        <input type="tel" maxlength="1" inputmode="numeric" class="otp-box" placeholder="·">
                    </div>
                    <div class="resend-strip">
                        <span class="timer-text" id="timerText">Resend in <b id="timerVal">30s</b></span>
                        <button type="button" class="resend-btn" id="resendBtn" disabled>Resend OTP</button>
                    </div>
                </div>

                <div class="btn-group" id="btnGroup">
                    <button type="submit" id="authBtn" class="btn">
                        <div class="btn-spinner" id="btnSpinner"></div>
                        <svg id="btnIcon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="2.5" stroke-linecap="round">
                            <path
                                d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.8a16 16 0 0 0 6 6l.94-.94a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
                        </svg>
                        <span id="btnLabel">Continue with OTP</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <footer class="site-footer" id="elFooter">
        <div class="footer-inner">
            Crafted with <span class="footer-heart">❤️</span> by <a href="#">LazyyXD</a>
        </div>
    </footer>

    <script src="includes/assets/js/auth-bridge.js"></script>
    <script src="includes/assets/js/login-ui.js"></script>
</body>

</html>