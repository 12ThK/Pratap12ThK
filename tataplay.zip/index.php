<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/includes/core/functions.php';

if (!is_logged_in()) {
    header("Location: login");
    exit;
}

// ─── TOKEN REFRESH HANDLER ──────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'save_refreshed_tokens') {
    $newAccess = $_POST['accessToken'] ?? '';
    $newRefresh = $_POST['refreshToken'] ?? '';
    $newExpiry = $_POST['expiresIn'] ?? '';

    if ($newAccess && $newRefresh) {
        $raw = @file_get_contents(ACCOUNT_FILE);
        $json = json_decode($raw, true);
        if ($json && isset($json['data'])) {
            $json['data']['accessToken'] = $newAccess;
            $json['data']['refreshToken'] = $newRefresh;
            if ($newExpiry) {
                $json['data']['expiresIn'] = $newExpiry;
            }
            if (save_raw_account($json)) {
                $_SESSION['refresh_msg'] = 'Token regenerated & saved successfully.';
                $_SESSION['refresh_status'] = 'success';
            } else {
                $_SESSION['refresh_msg'] = 'Token regenerated but failed to write file.';
                $_SESSION['refresh_status'] = 'error';
            }
        } else {
            $_SESSION['refresh_msg'] = 'Could not read account file for update.';
            $_SESSION['refresh_status'] = 'error';
        }
    } else {
        $_SESSION['refresh_msg'] = $_POST['error_msg'] ?? 'Refresh API returned an error.';
        $_SESSION['refresh_status'] = 'error';
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ─── FETCH REFRESH MESSAGES ─────────────────────────────────
$refreshMsg = $_SESSION['refresh_msg'] ?? '';
$refreshStatus = $_SESSION['refresh_status'] ?? '';
unset($_SESSION['refresh_msg'], $_SESSION['refresh_status']);

// ─── VERIFY CREDENTIALS ─────────────────────────────────────
$creds = get_creds();
if (is_logged_in() && !$creds) {
    if (defined('ACCOUNT_FILE') && file_exists(ACCOUNT_FILE)) {
        @unlink(ACCOUNT_FILE);
    }
    session_unset();
    session_destroy();
    header("Location: login");
    exit;
}

// ─── LOAD CHANNELS ──────────────────────────────────────────
$channelsFile = defined('CHANNELS_FILE') ? CHANNELS_FILE : __DIR__ . '/includes/data/channels.json';
if (!file_exists($channelsFile)) {
    check_and_download_channels();
}
$channels = [];
if (file_exists($channelsFile)) {
    $channels = json_decode(file_get_contents($channelsFile), true) ?? [];
}

// ─── BUILD PLAYLIST URL ─────────────────────────────────────
$playlistUrl = getBaseUrl() . '/playlist.m3u';

// ─── OUTPUT HTML (unchanged from original) ──────────────────
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Tata Play Web - Portal</title>
    <link rel="shortcut icon" href="includes/assets/images/favicon.ico" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
        rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.7.11/shaka-player.ui.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.7.11/controls.min.css">
    <link href="includes/assets/css/styles.css" rel="stylesheet">
    <style>
        :root {
            --bg: #07070a;
            --surface: #0e0e14;
            --surface-2: #15151f;
            --surface-3: #1c1c2b;
            --border: rgba(255, 255, 255, 0.06);
            --border-hover: rgba(57, 255, 20, 0.3);
            --text: #f0f0f5;
            --text-2: #a0a0b8;
            --text-3: #606078;
            --font: 'Space Grotesk', sans-serif;
            --mono: 'JetBrains Mono', monospace;
            --green: #39ff14;
            --green-soft: rgba(57, 255, 20, 0.15);
            --green-glow: rgba(57, 255, 20, 0.25);
            --red: #ff4d4d;
            --blue: #00d4ff;
            --blue-light: #33ddff;
            --blue-soft: rgba(0, 212, 255, 0.15);
            --blue-glow: rgba(0, 212, 255, 0.25);
        }

        * {
            scrollbar-width: thin;
            scrollbar-color: rgba(57, 255, 20, 0.2) var(--bg);
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(57, 255, 20, 0.15);
            border-radius: 3px;
            border: 1px solid rgba(57, 255, 20, 0.25);
            transition: all 0.3s;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--green);
            border-color: var(--green);
            box-shadow: 0 0 10px var(--green-glow);
        }

        html {
            height: 100dvh;
            width: 100vw;
            overflow: hidden;
        }

        body {
            margin: 0;
            display: flex;
            flex-direction: row;
            align-items: stretch;
            justify-content: flex-start;
            padding: 0;
            height: 100dvh;
            width: 100vw;
            overflow: hidden;
            background: var(--bg);
            color: var(--text);
            font-family: var(--font);
        }

        .sidebar {
            width: 280px;
            background: rgba(14, 14, 20, 0.6);
            backdrop-filter: blur(24px) saturate(1.4);
            -webkit-backdrop-filter: blur(24px) saturate(1.4);
            border-right: 1px solid rgba(255, 255, 255, 0.04);
            padding: 24px 24px 72px 24px;
            display: flex;
            flex-direction: column;
            z-index: 10;
            flex-shrink: 0;
            position: relative;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--green), transparent);
            opacity: 0.5;
        }

        .sidebar::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, rgba(16, 185, 129, 0.04) 0%, transparent 40%);
            pointer-events: none;
        }

        .brand {
            margin-bottom: 24px;
        }

        .brand-logo-wrap {
            margin-bottom: 10px;
        }

        .brand-logo-wrap img {
            height: 32px;
            filter: drop-shadow(0 0 8px var(--green-glow));
        }

        .brand-name {
            font-size: 18px;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text);
        }

        .brand-name span {
            color: var(--green);
            text-shadow: 0 0 10px var(--green-glow);
        }

        .brand-sep {
            display: none;
        }

        .brand-tag {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--text-3);
            font-family: var(--mono);
            margin-top: 4px;
            display: block;
        }

        .profile-card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.05);
            position: relative;
            overflow: hidden;
        }

        .profile-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.4), transparent);
        }

        .profile-card::after {
            content: '';
            position: absolute;
            top: -60%;
            left: -60%;
            width: 220%;
            height: 220%;
            background: radial-gradient(circle, rgba(16, 185, 129, 0.08) 0%, transparent 60%);
            pointer-events: none;
        }

        .profile-avatar {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            margin-bottom: 14px;
            box-shadow: 0 0 20px var(--green-glow);
            overflow: hidden;
            background: var(--surface-3);
            border: 1px solid var(--border);
            position: relative;
            z-index: 1;
        }

        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-details {
            position: relative;
            z-index: 1;
        }

        .profile-details h2 {
            font-size: 15px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 4px;
        }

        .profile-details p {
            font-size: 12px;
            color: var(--text-2);
            font-family: var(--mono);
        }

        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            background: var(--green-soft);
            color: var(--green);
            border-radius: 6px;
            font-size: 10px;
            font-weight: 700;
            margin-top: 8px;
            text-transform: uppercase;
            border: 1px solid rgba(57, 255, 20, 0.2);
            box-shadow: 0 0 8px var(--green-glow);
        }

        .sidebar-actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
            flex-grow: 1;
        }

        .playlist-input-wrapper {
            margin-bottom: 0;
        }

        .playlist-input-wrapper label {
            font-size: 11px;
            font-weight: 600;
            color: var(--text-2);
            margin-bottom: 6px;
            display: block;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .playlist-copy-wrap {
            position: relative;
            display: flex;
            align-items: center;
        }

        .playlist-copy-wrap .playlist-input {
            width: 100%;
            padding: 12px 44px 12px 14px !important;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-family: var(--mono);
            font-size: 11px;
            outline: none;
            cursor: text;
            transition: all 0.2s;
        }

        .playlist-copy-wrap .playlist-input:focus {
            border-color: var(--green);
            background: var(--surface);
            box-shadow: 0 0 0 3px var(--green-soft);
        }

        .playlist-copy-wrap .copy-icon-btn {
            position: absolute;
            right: 6px;
            top: 50%;
            transform: translateY(-50%);
            border-radius: 6px;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: var(--green);
        }

        .playlist-copy-wrap .copy-icon-btn:hover {
            background: rgba(16, 185, 129, 0.2);
            border-color: rgba(16, 185, 129, 0.4);
            box-shadow: 0 0 8px var(--green-glow);
        }

        .playlist-copy-wrap .copy-icon-btn.info {
            background: rgba(0, 212, 255, 0.1);
            border: 1px solid rgba(0, 212, 255, 0.2);
            color: #00d4ff;
        }

        .playlist-copy-wrap .copy-icon-btn.info:hover {
            background: rgba(0, 212, 255, 0.2);
            border-color: rgba(0, 212, 255, 0.4);
            box-shadow: 0 0 8px rgba(0, 212, 255, 0.3);
            color: #00d4ff;
        }

        .action-btn {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            color: var(--text);
            font-family: var(--font);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }

        .action-btn:hover {
            background: rgba(16, 185, 129, 0.08);
            border-color: rgba(57, 255, 20, 0.3);
            color: var(--green);
            box-shadow: 0 0 20px var(--green-glow), inset 0 1px 0 rgba(57, 255, 20, 0.1);
            transform: translateY(-1px);
        }

        .action-btn svg {
            flex-shrink: 0;
        }

        .action-btn.danger {
            background: rgba(255, 77, 77, 0.05);
            border-color: rgba(255, 77, 77, 0.2);
            color: var(--red);
        }

        .action-btn.danger:hover {
            background: rgba(255, 77, 77, 0.1);
            border-color: rgba(255, 77, 77, 0.4);
            box-shadow: 0 0 20px rgba(255, 77, 77, 0.15), inset 0 1px 0 rgba(255, 77, 77, 0.1);
            transform: translateY(-1px);
        }

        .action-btn.info {
            background: rgba(0, 212, 255, 0.05);
            border-color: rgba(0, 212, 255, 0.2);
            color: var(--blue);
        }

        .action-btn.info:hover {
            background: rgba(0, 212, 255, 0.1);
            border-color: rgba(0, 212, 255, 0.4);
            box-shadow: 0 0 20px rgba(0, 212, 255, 0.15), inset 0 1px 0 rgba(0, 212, 255, 0.1);
            transform: translateY(-1px);
        }

        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            position: relative;
            height: 100dvh;
            overflow: hidden;
            background: #020617;
        }

        .main-content::before {
            content: '';
            position: absolute;
            inset: 0;
            z-index: 0;
            background-image: radial-gradient(circle 500px at 50% 300px, rgba(16, 185, 129, 0.35), transparent);
            pointer-events: none;
        }

        .topbar {
            position: relative;
            z-index: 10;
            padding: 20px 40px;
            background: rgba(2, 6, 23, 0.5);
            backdrop-filter: blur(24px) saturate(1.5);
            -webkit-backdrop-filter: blur(24px) saturate(1.5);
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .topbar-left h2 {
            font-size: 22px;
            font-weight: 700;
            color: var(--text);
            letter-spacing: -0.5px;
        }

        .topbar-left p {
            font-size: 13px;
            color: var(--text-2);
            margin-top: 4px;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .search-wrap {
            position: relative;
        }

        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-3);
            pointer-events: none;
        }

        .search-input {
            width: 260px;
            height: 42px;
            padding: 10px 14px 10px 36px;
            background: rgba(255, 255, 255, 0.04);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 12px;
            font-family: var(--font);
            font-size: 13px;
            color: var(--text);
            transition: all 0.3s;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }

        .search-input::placeholder {
            color: var(--text-3);
        }

        .search-input:focus {
            border-color: rgba(16, 185, 129, 0.5);
            outline: none;
            background: rgba(255, 255, 255, 0.06);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1), 0 0 20px rgba(16, 185, 129, 0.1);
        }

        .custom-dropdown-container {
            position: relative;
        }

        .custom-dropdown-btn {
            display: inline-flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            height: 42px;
            padding: 10px 16px;
            background: rgba(255, 255, 255, 0.04);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 12px;
            font-family: var(--font);
            font-size: 13px;
            font-weight: 500;
            color: var(--text);
            cursor: pointer;
            min-width: 140px;
            transition: all 0.3s;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }

        .custom-dropdown-btn:hover,
        .custom-dropdown-btn.active {
            border-color: rgba(16, 185, 129, 0.4);
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.15), inset 0 1px 0 rgba(16, 185, 129, 0.1);
            background: rgba(255, 255, 255, 0.06);
        }

        .custom-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: #12121e;
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 14px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.7);
            min-width: 200px;
            max-height: 300px;
            overflow-y: auto;
            z-index: 50;
            display: none;
            flex-direction: column;
            padding: 6px;
        }

        .custom-dropdown-menu.show {
            display: flex;
            animation: fadeIn 0.2s ease;
        }

        .custom-dropdown-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .custom-dropdown-list li {
            padding: 10px 14px;
            font-size: 13px;
            color: var(--text-2);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }

        .custom-dropdown-list li:hover {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
        }

        .custom-dropdown-list li.active {
            background: rgba(16, 185, 129, 0.12);
            color: var(--green);
            font-weight: 600;
            box-shadow: inset 0 0 12px rgba(16, 185, 129, 0.1);
        }

        .grid-container {
            position: relative;
            z-index: 1;
            padding: 40px;
            min-height: 0;
            overflow-y: auto;
            flex-grow: 1;
            padding-bottom: 40px;
            scroll-behavior: smooth;
        }

        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
        }

        .channel-item {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 16px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.04);
            overflow: hidden;
        }

        .channel-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.03), transparent);
            transition: left 0.6s ease;
            pointer-events: none;
        }

        .channel-item:hover::before {
            left: 100%;
        }

        .channel-item:hover {
            border-color: rgba(16, 185, 129, 0.35);
            background: rgba(255, 255, 255, 0.05);
            box-shadow: 0 0 30px rgba(16, 185, 129, 0.15), 0 12px 32px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(16, 185, 129, 0.1);
            transform: translateY(-6px) scale(1.02);
        }

        .channel-logo-wrapper {
            height: 60px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .channel-logo-wrapper img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.5));
        }

        .channel-name {
            font-size: 14px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .channel-group {
            font-size: 10px;
            color: rgba(57, 255, 20, 0.55);
            text-transform: uppercase;
            font-family: var(--mono);
            letter-spacing: 0.5px;
            transition: color 0.3s ease;
        }

        .channel-item:hover .channel-group {
            color: var(--green);
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-top: 20px;
            margin-bottom: 80px;
            flex-wrap: wrap;
        }

        .page-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 38px;
            height: 38px;
            padding: 0 12px;
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 10px;
            color: var(--text-2);
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
            cursor: pointer;
        }

        .page-btn:hover {
            border-color: rgba(16, 185, 129, 0.4);
            color: var(--green);
            background: rgba(16, 185, 129, 0.06);
            box-shadow: 0 0 15px rgba(16, 185, 129, 0.15), inset 0 1px 0 rgba(16, 185, 129, 0.1);
        }

        .page-btn.active {
            background: linear-gradient(135deg, var(--green), #10b981);
            border-color: transparent;
            color: #000;
            font-weight: 700;
            box-shadow: 0 0 25px rgba(16, 185, 129, 0.35), 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .page-btn.disabled {
            opacity: 0.2;
            cursor: not-allowed;
            pointer-events: none;
        }

        .alert {
            display: none;
            align-items: center;
            gap: 10px;
            padding: 14px 18px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            border: 1px solid transparent;
            margin-bottom: 24px;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        .alert.show {
            display: flex;
            animation: slideDown 0.3s ease;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.08);
            color: var(--green);
            border-color: rgba(16, 185, 129, 0.2);
            box-shadow: 0 0 15px rgba(16, 185, 129, 0.1), inset 0 1px 0 rgba(16, 185, 129, 0.1);
        }

        .alert-error {
            background: rgba(255, 77, 77, 0.08);
            color: var(--red);
            border-color: rgba(255, 77, 77, 0.2);
            box-shadow: 0 0 15px rgba(255, 77, 77, 0.1), inset 0 1px 0 rgba(255, 77, 77, 0.1);
        }

        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(5, 5, 10, 0.85);
            backdrop-filter: blur(12px);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            visibility: hidden;
            transition: all 0.4s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            width: 90%;
            max-width: 800px;
            background: rgba(14, 14, 20, 0.75);
            backdrop-filter: blur(32px) saturate(1.6);
            -webkit-backdrop-filter: blur(32px) saturate(1.6);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.06);
            transform: scale(0.95) translateY(20px);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(255, 255, 255, 0.06);
            position: relative;
        }

        .modal-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.5), transparent);
            z-index: 1;
        }

        .modal-overlay.active .modal-content {
            transform: scale(1) translateY(0);
        }

        .modal-header {
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            background: rgba(255, 255, 255, 0.02);
        }

        .modal-title {
            font-weight: 700;
            font-size: 16px;
            color: var(--text);
        }

        .btn-close {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.08);
            width: 34px;
            height: 34px;
            border-radius: 10px;
            cursor: pointer;
            color: var(--text-2);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .btn-close:hover {
            background: rgba(255, 77, 77, 0.15);
            color: var(--red);
            border-color: rgba(255, 77, 77, 0.3);
            box-shadow: 0 0 15px rgba(255, 77, 77, 0.2);
            transform: rotate(90deg);
        }

        .player-wrapper {
            width: 100%;
            aspect-ratio: 16/9;
            background: #000;
            position: relative;
        }

        .player-wrapper::before {
            content: 'Initializing Uplink...';
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--green);
            font-family: var(--mono);
            font-size: 14px;
            opacity: 0.5;
            z-index: 0;
        }

        .player-wrapper video {
            width: 100%;
            height: 100%;
            position: relative;
            z-index: 1;
        }

        .confirm-modal-content {
            width: 90%;
            max-width: 400px;
            background: rgba(14, 14, 20, 0.75);
            backdrop-filter: blur(32px) saturate(1.6);
            -webkit-backdrop-filter: blur(32px) saturate(1.6);
            border-radius: 20px;
            padding: 32px;
            text-align: center;
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.06);
            transform: scale(0.95) translateY(20px);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(255, 255, 255, 0.06);
            position: relative;
        }

        .confirm-modal-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.5), transparent);
        }

        .modal-overlay.active .confirm-modal-content {
            transform: scale(1) translateY(0);
        }

        .confirm-icon {
            width: 64px;
            height: 64px;
            background: rgba(255, 77, 77, 0.08);
            color: var(--red);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 0 20px rgba(255, 77, 77, 0.1), inset 0 1px 0 rgba(255, 77, 77, 0.1);
            border: 1px solid rgba(255, 77, 77, 0.15);
            position: relative;
        }

        .confirm-icon::after {
            content: '';
            position: absolute;
            inset: -5px;
            border-radius: 50%;
            border: 1px dashed currentColor;
            animation: spin 10s linear infinite;
            opacity: 0.5;
        }

        .confirm-icon.info {
            background: rgba(16, 185, 129, 0.08);
            color: var(--green);
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.1), inset 0 1px 0 rgba(16, 185, 129, 0.1);
            border-color: rgba(16, 185, 129, 0.15);
        }

        .confirm-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 8px;
        }

        .confirm-text {
            font-size: 13px;
            color: var(--text-2);
            margin-bottom: 24px;
            line-height: 1.6;
        }

        .confirm-actions {
            display: flex;
            gap: 12px;
        }

        .confirm-actions button {
            flex: 1;
            padding: 12px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            border: 1px solid transparent;
            transition: all 0.3s;
        }

        .btn-cancel {
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(255, 255, 255, 0.08);
            color: var(--text);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }

        .btn-cancel:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(255, 255, 255, 0.12);
        }

        .btn-confirm {
            background: linear-gradient(135deg, var(--green), #10b981);
            color: #000;
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.25), 0 4px 12px rgba(0, 0, 0, 0.3);
            font-weight: 700;
        }

        .btn-confirm:hover {
            box-shadow: 0 0 30px rgba(16, 185, 129, 0.35), 0 6px 16px rgba(0, 0, 0, 0.4);
            transform: translateY(-1px);
        }

        .btn-confirm.danger {
            background: linear-gradient(135deg, var(--red), #e63946);
            color: #fff;
            box-shadow: 0 0 20px rgba(255, 77, 77, 0.2), 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .btn-confirm.danger:hover {
            box-shadow: 0 0 30px rgba(255, 77, 77, 0.3), 0 6px 16px rgba(0, 0, 0, 0.4);
            transform: translateY(-1px);
        }

        .snackbar {
            visibility: hidden;
            min-width: 280px;
            background: rgba(14, 14, 20, 0.8);
            backdrop-filter: blur(24px) saturate(1.5);
            -webkit-backdrop-filter: blur(24px) saturate(1.5);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: var(--text);
            text-align: center;
            border-radius: 14px;
            padding: 14px 24px;
            position: fixed;
            z-index: 2000;
            left: 50%;
            bottom: 30px;
            transform: translateX(-50%) translateY(30px);
            opacity: 0;
            font-size: 13px;
            font-weight: 600;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5), 0 0 20px rgba(16, 185, 129, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.06);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .snackbar.show {
            visibility: visible;
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }

        .snackbar-icon {
            color: var(--green);
            filter: drop-shadow(0 0 5px var(--green-glow));
        }

        .site-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 100;
            background: rgba(7, 7, 10, 0.85);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .footer-inner {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 40px;
            padding: 0 20px;
            padding-bottom: env(safe-area-inset-bottom, 0px);
            text-align: center;
            font-size: 12px;
            color: var(--text-3);
            font-weight: 500;
            line-height: 1;
        }

        .footer-inner a {
            color: var(--green);
            text-decoration: none;
            font-weight: 600;
            text-shadow: 0 0 8px var(--green-glow);
            transition: all 0.2s;
        }

        .footer-inner a:hover {
            color: #4fff3f;
        }

        .footer-heart {
            color: var(--red);
            text-shadow: 0 0 8px rgba(255, 77, 77, 0.3);
        }

        .hide-mobile {
            display: inline;
        }

        .no-results {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: var(--text-2);
            font-size: 14px;
        }

        @keyframes spin {
            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .mobile-toggle {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border);
            color: var(--text);
            padding: 8px;
            border-radius: 8px;
            cursor: pointer;
            margin-right: 12px;
        }

        .mobile-toggle svg {
            width: 20px;
            height: 20px;
            stroke: currentColor;
            stroke-width: 2.5;
            stroke-linecap: round;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(4px);
            z-index: 99;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .sidebar-overlay.active {
            display: block;
            opacity: 1;
        }

        .mobile-copy-btn {
            display: none;
        }

        @media (max-width: 900px) {
            .mobile-copy-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-left: auto;
                background: rgba(16, 185, 129, 0.1);
                color: var(--green);
                border: 1px solid rgba(16, 185, 129, 0.3);
                height: 40px;
                padding: 0 14px;
                gap: 6px;
                border-radius: 12px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
                box-shadow: inset 0 1px 0 rgba(16, 185, 129, 0.1);
            }

            .mobile-copy-btn:hover {
                background: rgba(16, 185, 129, 0.2);
                box-shadow: 0 0 15px rgba(16, 185, 129, 0.3), inset 0 1px 0 rgba(16, 185, 129, 0.2);
            }

            .mobile-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                position: fixed;
                top: 0;
                bottom: 0;
                left: -320px;
                width: 320px;
                padding: 20px 16px 80px 16px;
                z-index: 200;
                transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
                background: rgba(14, 14, 20, 0.98);
                overflow-y: auto;
            }

            .sidebar.active {
                transform: translateX(320px);
            }

            .brand {
                margin-bottom: 24px;
            }

            .profile-card {
                padding: 12px !important;
                margin-bottom: 20px !important;
                gap: 12px !important;
            }

            .profile-avatar img {
                width: 44px !important;
                height: 44px !important;
            }

            .profile-details h2 {
                font-size: 1rem !important;
                margin-bottom: 2px !important;
            }

            .profile-details p {
                font-size: 0.75rem !important;
                margin-bottom: 4px !important;
            }

            .playlist-input-wrapper {
                margin-bottom: 16px;
            }

            .action-btn {
                padding: 10px 14px;
                font-size: 12px;
            }

            .topbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
                height: auto;
                padding: 16px 20px;
            }

            .topbar-left {
                width: 100%;
                display: flex;
                align-items: center;
            }

            .topbar-left h2 {
                font-size: 1.2rem;
            }

            .topbar-right {
                width: 100%;
                flex-direction: row;
                gap: 10px;
                align-items: center;
            }

            .custom-dropdown-container {
                flex: 0 0 auto;
                min-width: 120px;
                max-width: 40%;
                order: 2;
            }

            .search-wrap {
                flex: 1 1 auto;
                width: 100%;
                order: 1;
            }

            .grid-container {
                padding: 16px;
            }

            .card-grid {
                grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
                gap: 16px;
            }

            .channel-card {
                padding: 16px 12px;
            }

            .channel-logo {
                width: 60px;
                height: 60px;
            }

            .channel-name {
                font-size: 13px;
            }

            .site-footer {
                padding: 0;
            }

            .footer-inner {
                padding: 6px 10px;
                font-size: 11px;
            }

            .hide-mobile {
                display: none !important;
            }
        }
    </style>
</head>

<body>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="brand" id="elBrand">
            <div class="brand-logo-wrap">
                <img src="includes/assets/images/logo.png" alt="Tata Play" onerror="this.style.display='none'">
            </div>
            <span class="brand-name">TATA <span>PLAY</span></span>
            <div class="brand-sep"></div>
            <span class="brand-tag">WebTV</span>
        </div>

        <div class="profile-card"
            style="flex-shrink: 0; display: flex; flex-direction: row; align-items: center; gap: 16px; padding: 16px;">
            <div class="profile-avatar" style="flex-shrink: 0;">
                <img src="https://i.pravatar.cc/150?u=<?php echo urlencode($creds['sid']); ?>" alt="Profile Avatar"
                    style="width: 56px; height: 56px; border-radius: 12px; display: block;">
            </div>
            <div class="profile-details"
                style="flex-shrink: 0; display: flex; flex-direction: column; align-items: flex-start;">
                <h2 style="margin: 0 0 4px 0; font-size: 1.1rem; line-height: 1.2;">
                    <?php echo htmlspecialchars($creds['sname']); ?>
                </h2>
                <p style="margin: 0 0 6px 0; font-size: 0.85rem; color: #a1a1aa;">SID:
                    <?php echo htmlspecialchars($creds['sid']); ?>
                </p>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 0.85rem; color: #a1a1aa;">Status:</span>
                    <div class="status-badge"
                        style="margin: 0; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.5px; display: inline-flex; align-items: center; justify-content: center; height: 20px;">
                        <?php echo htmlspecialchars($creds['acStatus']); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="sidebar-actions">
            <div class="playlist-input-wrapper">
                <label>M3U Playlist URL</label>
                <div class="playlist-copy-wrap">
                    <input type="text" id="playlistUrl" class="playlist-input"
                        value="<?php echo htmlspecialchars($playlistUrl); ?>" readonly onclick="this.select();">
                    <button class="copy-icon-btn" onclick="copyPlaylist()" title="Copy M3U">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="2.5" stroke-linecap="round">
                            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                        </svg>
                    </button>
                </div>
            </div>

            <div class="playlist-input-wrapper">
                <label>Token Expiration Time</label>
                <div class="playlist-copy-wrap">
                    <?php
                    $expiryDate = 'Unknown';
                    if (!empty($creds['expiresIn'])) {
                        $ts = floor($creds['expiresIn'] / 1000);
                        $dt = new DateTime("@$ts");
                        $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
                        $expiryDate = $dt->format('d M Y, h:i A') . ' IST';
                    }
                    ?>
                    <input type="text" class="playlist-input" value="<?php echo htmlspecialchars($expiryDate); ?>"
                        readonly style="cursor: default;">
                    <button class="copy-icon-btn info" onclick="openRefreshModal()" title="Refresh Token">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="2.5" stroke-linecap="round">
                            <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.92-10.44l5.58 5.58" />
                        </svg>
                    </button>
                </div>
            </div>

            <form method="POST" id="refreshForm" style="display:none;">
                <input type="hidden" name="action" value="save_refreshed_tokens">
            </form>

            <div
                style="background: rgba(255, 193, 7, 0.1); border: 1px solid rgba(255, 193, 7, 0.3); color: #ffc107; padding: 16px; border-radius: 8px; font-size: 0.85rem; line-height: 1.5;">
                <strong style="color: #ffd700; margin-bottom: 12px; display: block; font-size: 0.9rem;">⚠️ Important
                    Notes</strong>
                <div style="margin-bottom: 12px;">• Playlist is Widevine based; max 2 simultaneous streams allowed.
                </div>
                <div style="margin-bottom: 12px;">• Supported players: TiviMate, OTT Navigator, or any Widevine
                    supported player.</div>
                <div style="margin-bottom: 12px;">• Up to 7-day Catchup is supported automatically in players like
                    TiviMate.</div>
            </div>

            <div style="flex-grow: 1;"></div>

            <button class="action-btn danger" onclick="openSignOutModal()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                Sign Out
            </button>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <header class="topbar">
            <div class="topbar-left">
                <button class="mobile-toggle" onclick="toggleSidebar()" aria-label="Toggle Menu">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
                <div>
                    <h2>Live TV Guide</h2>
                    <p id="channelCountText">0 channels available</p>
                </div>
                <button class="mobile-copy-btn" onclick="copyPlaylist()" title="Copy M3U" aria-label="Copy Playlist">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
                        stroke-linecap="round">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                    <span>M3U</span>
                </button>
            </div>
            <div class="topbar-right">
                <div class="custom-dropdown-container" id="genreDropdownContainer">
                    <button id="genreDropdownBtn" class="custom-dropdown-btn" type="button"
                        onclick="toggleGenreDropdown(event)">
                        <span id="genreDropdownText">All Genres</span>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="2.5" stroke-linecap="round">
                            <path d="m19 9-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="genreDropdownMenu" class="custom-dropdown-menu">
                        <ul id="genreDropdownList" class="custom-dropdown-list">
                            <li onclick="selectGenre('All', this)" class="active">All Genres</li>
                        </ul>
                    </div>
                </div>
                <div class="search-wrap">
                    <svg class="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <input type="text" class="search-input" id="searchInput" placeholder="Search channels..."
                        onkeyup="handleFilterChange()">
                </div>
            </div>
        </header>

        <div class="grid-container">
            <div class="alert <?php echo $refreshMsg ? ($refreshStatus === 'error' ? 'alert-error' : 'alert-success') : ''; ?> <?php echo $refreshMsg ? 'show' : ''; ?>"
                id="elAlert" style="margin-bottom: 24px;">
                <?php if ($refreshMsg && $refreshStatus === 'error'): ?>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                        <circle cx="12" cy="12" r="10" />
                        <line x1="12" y1="8" x2="12" y2="12" />
                        <line x1="12" y1="16" x2="12.01" y2="16" />
                    </svg>
                <?php elseif ($refreshMsg): ?>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                        <polyline points="22 4 12 14.01 9 11.01" />
                    </svg>
                <?php endif; ?>
                <span id="alertText">
                    <?php echo htmlspecialchars($refreshMsg); ?>
                </span>
            </div>

            <div class="card-grid" id="channelGrid"></div>
            <div class="pagination" id="paginationControls"></div>
        </div>

        <footer class="site-footer" id="elFooter">
            <div class="footer-inner">
                Crafted with <span class="footer-heart">❤️</span> by <a href="#">LazyyXD</a>
            </div>
        </footer>
    </main>

    <!-- Confirm Modal -->
    <div class="modal-overlay" id="confirmModal">
        <div class="confirm-modal-content">
            <div class="confirm-icon" id="confirmIcon"></div>
            <div class="confirm-title" id="confirmTitle">Confirm</div>
            <div class="confirm-text" id="confirmText">Are you sure?</div>
            <div class="confirm-actions">
                <button class="btn-cancel" onclick="closeConfirmModal()">Cancel</button>
                <button class="btn-confirm" id="confirmBtn">Confirm</button>
            </div>
        </div>
    </div>

    <!-- Snackbar -->
    <div id="snackbar" class="snackbar">
        <svg class="snackbar-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
            stroke-width="2.5">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <polyline points="22 4 12 14.01 9 11.01" />
        </svg>
        <span id="snackbarText">Action completed successfully.</span>
    </div>

    <script>
        const allChannels = <?php echo json_encode($channels); ?>;
        let filteredChannels = [...allChannels];
        let currentPage = 1;
        const itemsPerPage = 100;

        document.addEventListener('DOMContentLoaded', () => {
            extractGenres();
            renderChannels();
        });

        let currentGenre = 'All';

        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
            const overlay = document.getElementById('sidebarOverlay');
            if (overlay.classList.contains('active')) {
                overlay.classList.remove('active');
                setTimeout(() => { overlay.style.display = 'none'; }, 300);
            } else {
                overlay.style.display = 'block';
                setTimeout(() => { overlay.classList.add('active'); }, 10);
            }
        }

        function closeSidebar() {
            document.getElementById('sidebar').classList.remove('active');
            const overlay = document.getElementById('sidebarOverlay');
            overlay.classList.remove('active');
            setTimeout(() => { overlay.style.display = 'none'; }, 300);
        }

        function toggleGenreDropdown(e) {
            e.stopPropagation();
            const menu = document.getElementById('genreDropdownMenu');
            const btn = document.getElementById('genreDropdownBtn');
            menu.classList.toggle('show');
            btn.classList.toggle('active');
        }

        function selectGenre(genre, element) {
            currentGenre = genre;
            document.getElementById('genreDropdownText').innerText = genre === 'All' ? 'All Genres' : genre;
            document.querySelectorAll('.custom-dropdown-list li').forEach(li => li.classList.remove('active'));
            if (element) element.classList.add('active');
            document.getElementById('genreDropdownMenu').classList.remove('show');
            document.getElementById('genreDropdownBtn').classList.remove('active');
            handleFilterChange();
        }

        document.addEventListener('click', (e) => {
            const container = document.getElementById('genreDropdownContainer');
            if (container && !container.contains(e.target)) {
                document.getElementById('genreDropdownMenu').classList.remove('show');
                document.getElementById('genreDropdownBtn').classList.remove('active');
            }
        });

        function extractGenres() {
            const list = document.getElementById('genreDropdownList');
            const genres = new Set();
            allChannels.forEach(c => {
                if (c.group_title) {
                    const cleanGenre = c.group_title.replace('TPlay | ', '').trim();
                    if (cleanGenre) genres.add(cleanGenre);
                }
            });
            Array.from(genres).sort().forEach(g => {
                const li = document.createElement('li');
                li.textContent = g;
                li.onclick = function () { selectGenre(g, this); };
                list.appendChild(li);
            });
        }

        function handleFilterChange() {
            const query = document.getElementById('searchInput').value.toLowerCase();
            const genre = currentGenre;
            filteredChannels = allChannels.filter(c => {
                const matchSearch = c.tvg_name.toLowerCase().includes(query);
                const cleanGenre = c.group_title ? c.group_title.replace('TPlay | ', '').trim() : '';
                const matchGenre = (genre === 'All') || (cleanGenre === genre);
                return matchSearch && matchGenre;
            });
            currentPage = 1;
            renderChannels();
        }

        function renderChannels() {
            const grid = document.getElementById('channelGrid');
            grid.innerHTML = '';
            document.getElementById('channelCountText').innerText = `${filteredChannels.length} channels available`;

            if (filteredChannels.length === 0) {
                grid.innerHTML = '<div class="no-results">No channels found matching your criteria.</div>';
                document.getElementById('paginationControls').innerHTML = '';
                return;
            }

            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const paginated = filteredChannels.slice(startIndex, endIndex);

            paginated.forEach(c => {
                const cleanGroup = c.group_title ? c.group_title.replace('TPlay | ', '') : '';
                const logo = c.tvg_logo || 'https://via.placeholder.com/80x40?text=No+Logo';
                const item = document.createElement('div');
                item.className = 'channel-item';
                item.onclick = () => window.location.href = c.tvg_id + '/player';
                item.innerHTML = `
                    <div class="channel-logo-wrapper">
                        <img src="${logo}" alt="Logo" loading="lazy" onerror="this.src='https://via.placeholder.com/80x40?text=No+Logo'">
                    </div>
                    <div class="channel-name" title="${c.tvg_name}">${c.tvg_name}</div>
                    <div class="channel-group">${cleanGroup}</div>
                `;
                grid.appendChild(item);
            });

            renderPagination();
        }

        function renderPagination() {
            const controls = document.getElementById('paginationControls');
            controls.innerHTML = '';
            const totalPages = Math.ceil(filteredChannels.length / itemsPerPage);
            if (totalPages <= 1) return;

            const createBtn = (text, page, disabled, active) => {
                const btn = document.createElement('button');
                btn.className = `page-btn ${disabled ? 'disabled' : ''} ${active ? 'active' : ''}`;
                btn.innerHTML = text;
                if (!disabled && !active) {
                    btn.onclick = () => {
                        currentPage = page;
                        renderChannels();
                        document.querySelector('.grid-container').scrollTo(0, 0);
                    };
                }
                return btn;
            };

            controls.appendChild(createBtn('&laquo;', 1, currentPage === 1, false));
            controls.appendChild(createBtn('&lsaquo;', currentPage - 1, currentPage === 1, false));

            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);
            for (let i = start; i <= end; i++) {
                controls.appendChild(createBtn(i, i, false, i === currentPage));
            }

            controls.appendChild(createBtn('&rsaquo;', currentPage + 1, currentPage === totalPages, false));
            controls.appendChild(createBtn('&raquo;', totalPages, currentPage === totalPages, false));
        }

        function showSnackbar(msg) {
            const sb = document.getElementById("snackbar");
            document.getElementById("snackbarText").innerText = msg;
            sb.classList.add("show");
            setTimeout(() => { sb.classList.remove("show"); }, 3000);
        }

        function copyPlaylist() {
            const input = document.getElementById('playlistUrl');
            input.select();
            document.execCommand('copy');
            showSnackbar("Playlist URL copied successfully!");
        }

        function openSignOutModal() {
            const iconHtml = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>';
            showConfirmModal("Sign Out", "Are you sure you want to sign out of your Tata Play account?", iconHtml, "danger", () => {
                location.href = 'logout?token=<?php echo $_SESSION['csrf_token'] ?? ''; ?>';
            });
        }

        function openRefreshModal() {
            const iconHtml = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.92-10.44l5.58 5.58"/></svg>';
            showConfirmModal("Refresh Token", "Are you sure you want to request a new session token?", iconHtml, "info", () => {
                doRefreshApi();
            });
        }

        function showConfirmModal(title, text, iconHtml, type, onConfirm) {
            document.getElementById('confirmTitle').innerText = title;
            document.getElementById('confirmText').innerText = text;
            const iconEl = document.getElementById('confirmIcon');
            iconEl.innerHTML = iconHtml;
            iconEl.className = `confirm-icon ${type}`;
            const btn = document.getElementById('confirmBtn');
            btn.className = `btn-confirm ${type}`;
            btn.onclick = () => {
                closeConfirmModal();
                onConfirm();
            };
            document.getElementById('confirmModal').classList.add('active');
        }

        function closeConfirmModal() {
            document.getElementById('confirmModal').classList.remove('active');
        }

        async function doRefreshApi() {
            const token = <?php echo json_encode($creds['accessToken']); ?>;
            try {
                const res = await fetch('api/refresh.php?token=' + encodeURIComponent(token));
                const data = await res.json();
                const form = document.getElementById('refreshForm');
                const addField = (name, value) => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = name;
                    input.value = value;
                    form.appendChild(input);
                };
                if (data.code === 0 && data.data) {
                    addField('accessToken', data.data.accessToken);
                    addField('refreshToken', data.data.refreshToken);
                    addField('expiresIn', data.data.expiresIn || '');
                } else {
                    addField('error_msg', 'Refresh failed: ' + (data.error_description || data.message || data.error || 'Unknown error'));
                }
                form.submit();
            } catch (e) {
                alert('Network error during refresh');
            }
        }
    </script>
</body>

</html>